import React from 'react';
import { NavLink } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Navbar.css';

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark py-3">
      <div className="container">
        <h1 className="navbar-brand text-primary">DASHBOARD</h1> {/* Use primary color for the brand */}

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <NavLink
                to="/"
                className="nav-link"
                style={({ isActive }) => ({
                  color: isActive ? '#1f5d5f' : '#ffffff', // Active link color (Teal)
                })}
                end
              >
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/saved-searches"
                className="nav-link"
                style={({ isActive }) => ({
                  color: isActive ? '#1f5d5f' : '#ffffff', // Active link color (Teal)
                })}
              >
                Saved Searches
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/history"
                className="nav-link"
                style={({ isActive }) => ({
                  color: isActive ? '#1f5d5f' : '#ffffff', // Active link color (Teal)
                })}
              >
                History
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
      
    </nav>

  );
}

export default Navbar;
