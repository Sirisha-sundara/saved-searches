import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/History.css'; // Ensure to link the necessary styles

function History() {
  const activityData = [
    {
      date: '2024-11-10',
      action: 'Viewed property: Modern Condo in NYC',
      type: 'view',
    },
    {
      date: '2024-11-09',
      action: 'Saved search: San Francisco Condos',
      type: 'search',
    },
    {
      date: '2024-11-08',
      action: 'Marked property as favorite: House in Miami',
      type: 'favorite',
    },
    {
      date: '2024-11-07',
      action: 'Viewed property: House in Los Angeles',
      type: 'view',
    },
    {
      date: '2024-11-06',
      action: 'Saved search: Miami Beach Properties',
      type: 'search',
    },
  ];

  return (
    <div className="container mt-4">
      <section className="history-section">
        <header className="text-center mb-4">
          <h3>Recent Activity</h3>
        </header>
        
        <ul className="list-group">
          {activityData.map((activity, index) => (
            <li
              key={index}
              className={`list-group-item d-flex justify-content-between align-items-center ${activity.type}`}
            >
              <span className="badge bg-secondary">{activity.date}</span>
              <p className="mb-0">{activity.action}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

export default History;
