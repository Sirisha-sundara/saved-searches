import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/HomePage.css';
 // Ensure Bootstrap styles are imported

function HomePage() {
  return (
    <div className="container mt-5">
      <div className="text-center">
        <h1 className="display-4 mb-4">Welcome to Dashboard</h1>
        <p className="lead mb-4">
          Manage your saved searches, recent activity, and favorite properties all in one place.
        </p>
        {/* Add any additional content here if needed */}
        <div className="mt-4">
          <button className="btn btn-primary btn-lg">Get Started</button>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
