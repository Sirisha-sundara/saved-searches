import React from 'react';

function FavoritesSection({ favorites, toggleFavorite }) {
  return (
    <div className="container mt-4">
      <h3 className="text-center mb-4">Your Favorite Properties</h3>

      {/* Check if there are favorites */}
      {favorites.length === 0 ? (
        <p className="text-center">No favorite properties added yet.</p>
      ) : (
        <ul className="list-group">
          {favorites.map((property, index) => (
            <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
              {property}
              <button
                className="btn btn-danger btn-sm"
                onClick={() => toggleFavorite(property)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default FavoritesSection;
