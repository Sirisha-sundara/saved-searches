import React from 'react';
import { NavLink } from 'react-router-dom';
import Navbar from '../components/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/DashboardPage.css'; 
// Make sure to add the necessary styles

function DashboardPage() {
  return (
    <div className="dashboard-container">
      <Navbar />
      
      {/* Dashboard Content */}
      <div className="container mt-4">
        <div className="row">
          {/* Saved Searches Section */}
          <div className="col-md-4 mb-4">
            <div className="dashboard-section saved-searches p-4 border rounded shadow-sm">
              <h2 className="h4">Saved Searches</h2>
              <NavLink to="/saved-searches">
                <button className="btn btn-primary w-100">View Saved Searches</button>
              </NavLink>
            </div>
          </div>

          {/* History Section */}
          <div className="col-md-4 mb-4">
            <div className="dashboard-section history p-4 border rounded shadow-sm">
              <h2 className="h4">History</h2>
              <NavLink to="/history">
                <button className="btn btn-secondary w-100">View History</button>
              </NavLink>
            </div>
          </div>

          {/* Favorites Section */}
          <div className="col-md-4 mb-4">
            <div className="dashboard-section favorites p-4 border rounded shadow-sm">
              <h2 className="h4">Favorites</h2>
              <NavLink to="/favorites">
                <button className="btn btn-success w-100">View Favorites</button>
              </NavLink>
            </div>
          </div>
          
          {/* Get Started Section */}
          <div className="col-md-4 mb-4">
            <div className="dashboard-section get-started p-4 border rounded shadow-sm">
              <h2 className="h4">Get Started</h2>
              <NavLink to="/get-started">
                <button className="btn btn-warning w-100">Get Started</button>
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardPage;
