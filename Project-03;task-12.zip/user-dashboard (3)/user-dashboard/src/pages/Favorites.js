import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Favorites.css';  // If the CSS file is in 'src/styles'


const Favorites = ({ favorites = [] }) => {  // Default to empty array if undefined
  return (
    <div className="favorites-section container mt-5">
      <h3 className="h4 mb-4 text-primary">Your Favorite Properties</h3>

      {favorites.length === 0 ? (
        <p className="text-muted">No favorite properties added yet.</p>
      ) : (
        <ul className="list-group">
          {favorites.map((property, index) => (
            <li 
              key={index} 
              className="list-group-item d-flex justify-content-between align-items-center shadow-sm p-3 mb-3 bg-white rounded"
            >
              <span className="font-weight-bold text-dark">{property}</span>
              <button className="btn btn-danger btn-sm">
                <i className="bi bi-trash"></i> Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Favorites;
