import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/SavedSearchesPage.css';

function SavedSearchesPage() {
  const [favorites, setFavorites] = useState([]); 
  const [searchQuery, setSearchQuery] = useState(''); 

  const properties = [
    {
      name: '2-bedroom Apartment in NYC',
      image: 'https://www.costanitavillas.com/content/uploads/2021/06/CostAnita_Wide_-35.jpg',
      location: 'New York City',
      price: '$1,500,000'
    },
    {
      name: 'Ocean-view House in California',
      image: 'https://cdn.homedsgn.com/wp-content/uploads/2016/11/Super-Villa-11.jpg',
      location: 'Malibu, California',
      price: '$3,200,000'
    },
    {
      name: 'Luxury Flat in London',
      image: 'https://cdn.trendhunterstatic.com/thumbs/315/los-angeles-house_1253127e.jpeg?auto=webp',
      location: 'Central London',
      price: '£2,800,000'
    },
    {
      name: 'Modern Villa in Los Angeles',
      image: 'https://images.squarespace-cdn.com/content/v1/5e30b4c769dcbf426b421101/1627933275320-72S5CGBXSZ8248X2K9X0/01-Bundy-Drive-Brentwood-Luxury-Poolside-Living.jpg?format=500w',
      location: 'Los Angeles, California',
      price: '$4,000,000'
    },
    {
      name: 'Beachfront House in Hawaii',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGFxnh3I9re8N288GkJ9xwPZKyQLaIs3OrCw&s',
      location: 'Hawaii',
      price: '$2,800,000'
    },
    {
      name: 'Penthouse in Tokyo',
      image: 'https://i.pinimg.com/736x/f5/94/4a/f5944a81e73812bbe72c89b96a32e625.jpg',
      location: 'Tokyo, Japan',
      price: '$5,000,000'
    },
    {
      name: 'Countryside Cottage in France',
      image: 'https://ml3nbhu8epgk.i.optimole.com/cb:xJRw~5229f/w:1024/h:576/q:mauto/f:best/ig:avif/https://www.hawaiiluxury.com/wp-content/uploads/2024/05/kai-ala-front-beach-view.jpg',
      location: 'Provence, France',
      price: '€1,200,000'
    },
    {
      name: 'Ski Chalet in Aspen',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrTOMUdrw9aFSRtdSkBByaJAC7gCL8Q7zQg8kgM0ZjM1iH7AxccDokBK-5IlPijjLfO2M&usqp=CAU',
      location: 'Aspen, Colorado',
      price: '$6,000,000'
    },
    {
      name: 'Ski Chalet in Aspen',
      image: 'https://th.bing.com/th?id=OIP.ohdyXRlOcsExd8QwhK7nggHaE8&w=306&h=204&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2',
      location: 'Aspen, Colorado',
      price: '$7,000,000'
    }
  ];
  

  const toggleFavorite = (property) => {
    setFavorites((prevFavorites) => {
      const isAlreadyFavorite = prevFavorites.some(fav => fav.name === property.name);
      if (isAlreadyFavorite) {
        return prevFavorites.filter(fav => fav.name !== property.name);
      } else {
        return [...prevFavorites, property];
      }
    });
  };

  const isFavorite = (property) => favorites.some(fav => fav.name === property.name);

  // Filter properties based on the search query
  const filteredProperties = properties.filter((property) =>
    property.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mt-4">
      {/* Header Section */}
      <div className="text-center mb-4">
        <h2>Your Saved Searches</h2>
        <p>Here are all your saved searches. You can view, edit, or delete any of them as needed.</p>
        
        {/* Search Bar */}
        <div className="d-flex justify-content-center">
          <input
            type="text"
            className="form-control w-50 me-2"
            placeholder="Search Saved Searches..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button className="btn btn-primary">Search</button>
        </div>
      </div>

      {/* Content Container */}
      <div className="row">
        {/* Saved Searches Grid */}
        {filteredProperties.length === 0 ? (
          <p>No properties found for the search query.</p>
        ) : (
          filteredProperties.map((property, index) => (
            <div className="col-md-4 mb-4" key={index}>
              <div className="card">
                <img
                  src={property.image}
                  alt={property.name}
                  className="card-img-top"
                />
                <div className="card-body">
                  <h5 className="card-title">{property.name}</h5>
                  <p><strong>Location:</strong> {property.location}</p>
                  <p><strong>Price:</strong> {property.price}</p>
                  <button
                    className={`btn ${isFavorite(property) ? 'btn-danger' : 'btn-outline-danger'}`}
                    onClick={() => toggleFavorite(property)}
                  >
                    {isFavorite(property) ? 'Remove from Favorites' : 'Add to Favorites'}
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Favorites Section */}
      <div className="mt-5">
        <h3>Your Favorite Properties</h3>
        <div className="row">
          {favorites.length === 0 ? (
            <p>No favorite properties added yet.</p>
          ) : (
            favorites.map((property, index) => (
              <div className="col-md-3 mb-4" key={index}>
                <div className="card">
                  <img
                    src={property.image}
                    alt={property.name}
                    className="card-img-top"
                  />
                  <div className="card-body">
                    <p>{property.name}</p>
                    <button
                      className="btn btn-danger"
                      onClick={() => toggleFavorite(property)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default SavedSearchesPage;



// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../styles/SavedSearchesPage.css';

// function SavedSearchesPage() {
//   const [favorites, setFavorites] = useState([]);
//   const [searchQuery, setSearchQuery] = useState('');
//   const [properties, setProperties] = useState([]);

//   useEffect(() => {
//     // Fetch properties from the API
//     axios.get('http://localhost:5003/api/saved-searches')
//       .then(response => {
//         setProperties(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching properties:', error);
//       });
//   }, []);

//   const toggleFavorite = (property) => {
//     setFavorites((prevFavorites) => {
//       const isAlreadyFavorite = prevFavorites.some(fav => fav.name === property.name);
//       if (isAlreadyFavorite) {
//         return prevFavorites.filter(fav => fav.name !== property.name);
//       } else {
//         return [...prevFavorites, property];
//       }
//     });
//   };

//   const isFavorite = (property) => favorites.some(fav => fav.name === property.name);

//   // Filter properties based on the search query
//   const filteredProperties = properties.filter((property) =>
//     property.name.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   return (
//     <div className="container mt-4">
//       {/* Header Section */}
//       <div className="text-center mb-4">
//         <h2>Your Saved Searches</h2>
//         <p>Here are all your saved searches. You can view, edit, or delete any of them as needed.</p>
        
//         {/* Search Bar */}
//         <div className="d-flex justify-content-center">
//           <input
//             type="text"
//             className="form-control w-50 me-2"
//             placeholder="Search Saved Searches..."
//             value={searchQuery}
//             onChange={(e) => setSearchQuery(e.target.value)}
//           />
//           <button className="btn btn-primary">Search</button>
//         </div>
//       </div>

//       {/* Content Container */}
//       <div className="row">
//         {/* Saved Searches Grid */}
//         {filteredProperties.length === 0 ? (
//           <p>No properties found for the search query.</p>
//         ) : (
//           filteredProperties.map((property, index) => (
//             <div className="col-md-4 mb-4" key={index}>
//               <div className="card">
//                 <img
//                   src={property.image}
//                   alt={property.name}
//                   className="card-img-top"
//                 />
//                 <div className="card-body">
//                   <h5 className="card-title">{property.name}</h5>
//                   <p><strong>Location:</strong> {property.location}</p>
//                   <p><strong>Price:</strong> {property.price}</p>
//                   <button
//                     className={`btn ${isFavorite(property) ? 'btn-danger' : 'btn-outline-danger'}`}
//                     onClick={() => toggleFavorite(property)}
//                   >
//                     {isFavorite(property) ? 'Remove from Favorites' : 'Add to Favorites'}
//                   </button>
//                 </div>
//               </div>
//             </div>
//           ))
//         )}
//       </div>

//       {/* Favorites Section */}
//       <div className="mt-5">
//         <h3>Your Favorite Properties</h3>
//         <div className="row">
//           {favorites.length === 0 ? (
//             <p>No favorite properties added yet.</p>
//           ) : (
//             favorites.map((property, index) => (
//               <div className="col-md-3 mb-4" key={index}>
//                 <div className="card">
//                   <img
//                     src={property.image}
//                     alt={property.name}
//                     className="card-img-top"
//                   />
//                   <div className="card-body">
//                     <p>{property.name}</p>
//                     <button
//                       className="btn btn-danger"
//                       onClick={() => toggleFavorite(property)}
//                     >
//                       Remove
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             ))
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default SavedSearchesPage;

