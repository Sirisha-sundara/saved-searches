import React from 'react';
import './styles/Favorite.css'

function FavoritesPage() {
  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Your Favorite Properties</h2>
      <p className="text-center mb-4">Browse your favorite properties saved for later consideration.</p>

      <div className="row">
        {/* Example property cards - you can replace this with dynamic content */}
        <div className="col-md-4 mb-4">
          <div className="card shadow-sm">
            <img
              src="https://via.placeholder.com/300x200"
              alt="Property 1"
              className="card-img-top"
            />
            <div className="card-body">
              <h5 className="card-title">Property 1</h5>
              <p className="card-text">Description of the property goes here.</p>
              <p className="card-text"><strong>Price:</strong> $1,000,000</p>
              <button className="btn btn-danger">Remove from Favorites</button>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow-sm">
            <img
              src="https://via.placeholder.com/300x200"
              alt="Property 2"
              className="card-img-top"
            />
            <div className="card-body">
              <h5 className="card-title">Property 2</h5>
              <p className="card-text">Description of the property goes here.</p>
              <p className="card-text"><strong>Price:</strong> $1,200,000</p>
              <button className="btn btn-danger">Remove from Favorites</button>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow-sm">
            <img
              src="https://via.placeholder.com/300x200"
              alt="Property 3"
              className="card-img-top"
            />
            <div className="card-body">
              <h5 className="card-title">Property 3</h5>
              <p className="card-text">Description of the property goes here.</p>
              <p className="card-text"><strong>Price:</strong> $1,500,000</p>
              <button className="btn btn-danger">Remove from Favorites</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FavoritesPage;
