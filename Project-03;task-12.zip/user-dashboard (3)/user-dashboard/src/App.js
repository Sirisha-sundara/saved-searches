import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import SavedSearchesPage from './pages/SavedSearchesPage';
import Favorites from './pages/Favorites';  // Import the Favorites component
import History from './pages/History';  // Import the History component
import './App.css';
import Login from './components/Login';
import Register from './components/Register';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        <Routes>
           <Route path="/" element={<Register />} />
            <Route path="/login" element={<Login />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/saved-searches" element={<SavedSearchesPage />} />
          <Route path="/favorites" element={<Favorites />} />
          <Route path="/history" element={<History />} /> {/* Add the History route */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
