const express = require('express');
const router = express.Router();

// Mock database for saved searches (replace with MongoDB queries in a real application)
const savedSearches = [
  {
    id: 1,
    name: '2-bedroom Apartment in NYC',
    image: 'https://www.costanitavillas.com/content/uploads/2021/06/CostAnita_Wide_-35.jpg',
    location: 'New York City',
    price: '$1,500,000'
  },
  // Add more properties here...
];

// Get all saved searches
router.get('/', (req, res) => {
  res.json(savedSearches);
});

// Add a new saved search
router.post('/', (req, res) => {
  const newSearch = req.body;
  savedSearches.push(newSearch);
  res.status(201).json(newSearch);
});

// Remove a saved search
router.delete('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const index = savedSearches.findIndex(search => search.id === id);
  if (index !== -1) {
    savedSearches.splice(index, 1);
    res.status(204).end();
  } else {
    res.status(404).json({ error: 'Property not found' });
  }
});

module.exports = router;
