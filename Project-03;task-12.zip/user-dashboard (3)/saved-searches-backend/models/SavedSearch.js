const mongoose = require('mongoose');

const savedSearchSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true
   },
  image: { type: String, required: true },
  location: { type: String, required: true },
  price: { type: String, required: true },
  isFavorite: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('SavedSearch', savedSearchSchema);
